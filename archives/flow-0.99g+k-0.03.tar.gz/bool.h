/*
 * bool.h
 */

#ifndef	_BOOL_H_
#define	_BOOL_H_	1

/*
 *	includes
 */

/*
 *	constants
 */

#define	TRUE	1
#define	FALSE	0

/*
 *	typedefs
 */

typedef	int	Bool;

/*
 *	externs
 */

/*
 *
 */

#endif

/*
 *
 */

