/*
 * param.h
 */

#ifndef	_PARAM_H_
#define	_PARAM_H_	1

/*
 *	includes
 */

/*
 *	constants
 */

#define PARAM_LEN	120

/*
 *	typedefs
 */

typedef	char	Param[ PARAM_LEN ];

/*
 *	externs
 */

/*
 *
 */

#endif

/*
 *
 */

