#ifndef _JIS_GRP_
#define _JIS_GRP_ 1
%
% JIS Symbol Library
%	see : http://www9.plala.or.jp/sgwr-t/c_sub/jis_fl.html
%
