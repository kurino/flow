/*
 * getcommand.h
 */

#ifndef	_GETCOMMAND_H_
#define	_GETCOMMAND_H_	1

/*
 *	includes
 */

#include "param.h"
#include "flowcom.h"

/*
 *	constants
 */

/*
 *	typedefs
 */

/*
 *	externs
 */

extern	FlowCom *getCommand ( char line[], Param plist );

/*
 *
 */

#endif

/*
 *
 */

