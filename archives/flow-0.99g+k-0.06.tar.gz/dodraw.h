/*
 * dodraw.h
 */

#ifndef	_DODRAW_H_
#define	_DODRAW_H_	1

/*
 *	includes
 */

#include "coord.h"

/*
 *	constants
 */

/*
 *	typedefs
 */

/*
 *	externs
 */

extern	void	doDraw ( char *name, char *pList, Coord curCoord, Coord curSize, char *curBoxPos, char *curPos );

/*
 *
 */

#endif

/*
 *
 */

