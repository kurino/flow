/*
 * dotext.h
 */

#ifndef	_DOTEXT_H_
#define	_DOTEXT_H_	1

/*
 *	includes
 */

/*
 *	constants
 */

#define	SPACEING_LENGTH	20

/*
 *	typedefs
 */

/*
 *	externs
 */

extern	void	doText ( void );
extern	void	setSpace ( char *l, char *t );

/*
 *
 */

#endif

/*
 *
 */

