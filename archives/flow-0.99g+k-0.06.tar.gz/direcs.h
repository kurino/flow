/*
 * direcs.h
 */

#ifndef	_DIRECS_H_
#define	_DIRECS_H_	1

/*
 *	includes
 */

/*
 *	constants
 */

/*
 *	typedefs
 */

typedef enum {
	UP_DIR = 0,
	DOWN_DIR = 1,
	LEFT_DIR = 2,
	RIGHT_DIR = 3
}	Direcs;

/*
 *	externs
 */

/*
 *
 */

#endif

/*
 *
 */

