/*
 * tracksymb.h
 */

#ifndef	_TRACKSYMB_H_
#define	_TRACKSYMB_H_	1

/*
 *
 */

/*
 *
 */

typedef enum {
	ArrowS,
	LineS,
	NoneS
} TrackSymb;

/*
 *
 */

#endif

/*
 *
 */

