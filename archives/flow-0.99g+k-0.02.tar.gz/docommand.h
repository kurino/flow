/*
 * docommand.h
 */

#ifndef	_DOCOMMAND_H_
#define	_DOCOMMAND_H_	1

/*
 *	includes
 */

#include "flowcom.h"
#include "param.h"

/*
 *	constants
 */

/*
 *	typedefs
 */

/*
 *	externs
 */

extern	int doCommand ( FlowCom *comPtr, Param pList );

/*
 *
 */

#endif

/*
 *
 */

