/*
 * eos.h
 */

#ifndef	_EOS_H_
#define	_EOS_H_	1

/*
 *	includes
 */

/*
 *	constants
 */

#define	EOS	'\0'

/*
 *	typedefs
 */


/*
 *	externs
 */

/*
 *
 */

#endif

/*
 *
 */

