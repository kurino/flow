/*
 * version.h
 */

#ifndef	_VERSION_H_
#define	_VERSION_H_	1

/*
 *	includes
 */

/*
 *	constants
 */

#define VERSION "0.99g+k-0.04 (2012/05/10)"

/*
 *	typedefs
 */

/*
 *	externs
 */

/*
 *
 */

#endif

/*
 *
 */

