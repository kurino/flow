/*
 * direcs.h
 */

#ifndef	_DIRECS_H_
#define	_DIRECS_H_	1

/*
 *	includes
 */

/*
 *	constants
 */

/*
 *	typedefs
 */

typedef enum {
	UpD,
	DownD,
	LeftD,
	RightD
}	Direcs;

/*
 *	externs
 */

/*
 *
 */

#endif

/*
 *
 */

