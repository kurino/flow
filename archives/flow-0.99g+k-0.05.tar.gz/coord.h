/*
 * coord.h
 */

#ifndef	_COORD_H_
#define	_COORD_H_	1

/*
 *	includes
 */

/*
 *	constants
 */

/*
 *	typedefs
 */

typedef struct {
	float	x;
	float	y;
} Coord;

/*
 *	externs
 */

/*
 *
 */

#endif

/*
 *
 */

